Innostudio.de
==============================================

Thank you for trying our fileuploader!

URL:
https://innostudio.de/fileuploader/

Permissions:
You are allowed only to test the plugin on your website or application in the next 2 working days.

Missing features:
- create txt file instead of upload
- themes
- templates
- no thumbnails
- upload progress bar
- synchron upload and chunks
- paste from clipboard
- exif orientation
- video thumbnails
- image editor
- sorter
- AmazonS3 example
- Laravel example
- file name generator
- API
- captions
- rest of examples

For any queries please contact Help Team via contact@innostudio.de

Innostudio.de
Iulian Galciuc
Germany