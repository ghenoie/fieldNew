<?php
//DATABASE CONNECTION VARIABLES
$host = '192.168.108.29'; // Host name
$username ='umshinidba'; // Mysql username
$password = '112358:112358'; // Mysql password
$db_name = 'umshini_bo'; // Database name
 
 
$tbl_members = "members_users";
$tbl_attempts ="loginAttempts";
$tbl_memberslog ="memberslog";

 