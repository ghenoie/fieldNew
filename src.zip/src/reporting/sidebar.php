<!-- href links different in integration, collaspe in class added server side in integration --> 
		<!-- sidebar --> 
		<div id="sidebar" class="sidebar-toggle">
			<ul class="nav nav-sidebar">
					<li>
							<a href="/">
									<i class="fa fa-home" aria-hidden="true"></i>
									<span>HOME</span>
							</a>
					</li>
 

					<li role="separator" class="divider"></li>

					<!--  how to  -->
					<li data-toggle="collapse" href="#how-to" aria-expanded="false" aria-controls="how-to">
						<a href="#">
							<i class="fa fa-gift" aria-hidden="true"></i>
							<span>Incentives</span>
						</a>
					</li>

					<li>
						<ul id="how-to" class="sub-menu collapse">
                     		<li><a href="./data-from-database.php">Incentive Amounts</a></li>
						</ul>
					</li>
					<!--  /how to  -->

					<li role="separator" class="divider"></li>
			</ul>
		</div>
		<!-- /sidebar -->